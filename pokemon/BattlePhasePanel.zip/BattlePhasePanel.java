import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BattlePhasePanel extends JPanel {
    private String playerActiveCreature;
    private String enemyCreature;

    public BattlePhasePanel(String playerActiveCreature, String enemyCreature) {
        this.playerActiveCreature = playerActiveCreature;
        this.enemyCreature = enemyCreature;

        setLayout(new BorderLayout());

        // Display enemy creature information
        JPanel enemyInfoPanel = createEnemyInfoPanel();
        add(enemyInfoPanel, BorderLayout.CENTER);

        // Action buttons
        JPanel actionPanel = createActionPanel();
        add(actionPanel, BorderLayout.SOUTH);
    }

    private JPanel createEnemyInfoPanel() {
        JPanel enemyInfoPanel = new JPanel(new GridLayout(5, 1));

        // Simulated data (replace with actual data from your game model)
        String enemyName = "Wild " + enemyCreature;
        int evolutionLevel = 1;
        String type = "Fire";
        String family = "Dragon";

        JLabel nameLabel = new JLabel("Name: " + enemyName);
        JLabel evolutionLabel = new JLabel("Evolution Level: " + evolutionLevel);
        JLabel typeLabel = new JLabel("Type: " + type);
        JLabel familyLabel = new JLabel("Family: " + family);

        enemyInfoPanel.add(nameLabel);
        enemyInfoPanel.add(evolutionLabel);
        enemyInfoPanel.add(typeLabel);
        enemyInfoPanel.add(familyLabel);

        return enemyInfoPanel;
    }

    private JPanel createActionPanel() {
        JPanel actionPanel = new JPanel(new GridLayout(1, 4));

        JButton attackButton = new JButton("Attack");
        JButton swapButton = new JButton("Swap Creature");
        JButton catchButton = new JButton("Catch");
        JButton runButton = new JButton("Run");

        attackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Add logic for attack
                JOptionPane.showMessageDialog(null, "You attacked the enemy!");
            }
        });

        swapButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Add logic for swapping active creature
                JOptionPane.showMessageDialog(null, "You swapped the active creature.");
            }
        });

        catchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Add logic for catching the enemy creature
                JOptionPane.showMessageDialog(null, "You caught the enemy creature!");
            }
        });

        runButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Add logic for running from the battle
                JOptionPane.showMessageDialog(null, "You ran from the battle!");
            }
        });

        actionPanel.add(attackButton);
        actionPanel.add(swapButton);
        actionPanel.add(catchButton);
        actionPanel.add(runButton);

        return actionPanel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Example usage in a standalone frame
            JFrame frame = new JFrame("Battle Phase");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add(new BattlePhasePanel("Charmander", "Pikachu"));
            frame.setSize(400, 300);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
